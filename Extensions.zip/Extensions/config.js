// API Configuration for Chrome Extension
// Toggle between development and production by commenting/uncommenting

// Development (Local)
window.API_CONFIG = {
  BASE_URL: "http://localhost:9000/api"
};

// Production
// window.API_CONFIG = {
//   BASE_URL: "https://www.supportplaner.com/v1/api"
// };
