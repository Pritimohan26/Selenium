package oracleTests;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.Test;
import utils.BaseTest;

import java.util.Set;

public class Invoice_Search extends BaseTest {

    String InvoiceNumber = System.getProperty("app.invoiceNumber");

    public void searchInvoiceNumber() throws InterruptedException {

        System.out.println("Invoice Number :: "+InvoiceNumber);

        //Click on search Invoice image
        driver.findElement(By.xpath("//div[@title='Search: Invoices']//a")).click();

        wait.until(ExpectedConditions.presenceOfElementLocated((By.xpath("//label[normalize-space()='Invoice Number']//parent::td[@class='x1og']//parent::tr//following-sibling::tr//input"))));
        driver.findElement(By.xpath("//label[normalize-space()='Invoice Number']//parent::td[@class='x1og']//parent::tr//following-sibling::tr//input")).click();
        driver.findElement(By.xpath("//label[normalize-space()='Invoice Number']//parent::td[@class='x1og']//parent::tr//following-sibling::tr//input")).sendKeys(InvoiceNumber);
        logStepWithScreenshot("User will populate Invoice number");
        Thread.sleep(500);
        driver.findElement(By.xpath("//button[normalize-space()='Search']")).click();
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@title='Search: Invoice']")));
        logStepWithScreenshot("User landed on searched Invoice page");

        int windowsBefore = driver.getWindowHandles().size();
        driver.findElement(By.xpath("//a[text()='" + InvoiceNumber + "']")).click();

        wait.until(ExpectedConditions.numberOfWindowsToBe(windowsBefore + 1));
        logStepWithScreenshot("User clicked on Invoice Number to get Invoice/PDF generated");

        String mainWindow = driver.getWindowHandle();
        // Get all window handles
        Set<String> allWindows = driver.getWindowHandles();

        // Switch to new window and close it
        for (String window : allWindows) {
            if (!window.equals(mainWindow)) {
                driver.switchTo().window(window);
                Thread.sleep(6000);
                logStepWithScreenshot("User clicked on Invoice Number to get pdf generated");
                driver.close(); // closes child window
            }
        }

        // Switch back to main window
        driver.switchTo().window(mainWindow);

    }

    @Test
    public void searchInvoice() throws InterruptedException {

        launchBrowserAndURL();
        login();
        userLandedOnHomePage();
        selectPayableFromHorizontalScroll();
        clickInvoiceAppInPayableTab();
        searchInvoiceNumber();
        logout();
        closeAllWindows();
    }
}
