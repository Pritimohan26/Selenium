package oracleTests;
import org.testng.TestNG;

public class Runner {
    public static void main(String[] args) {
        TestNG testng = new TestNG();
        testng.setTestClasses(new Class[] {
                //Generate_Invoice.class,
                Invoice_Search.class
        });
        testng.run();
    }
}
