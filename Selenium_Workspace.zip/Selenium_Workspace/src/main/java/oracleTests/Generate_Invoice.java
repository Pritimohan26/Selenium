package oracleTests;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.Test;
import utils.BaseTest;

public class Generate_Invoice extends BaseTest {

    String Invoice_Num = "029883";

    private void createInvoice_InputFields_GenericXpath(String REPLACE_STRING, String testData) throws InterruptedException {
        String InputBox_CreateInvoicePage = "//label[normalize-space()='" + REPLACE_STRING + "']//parent::td//following-sibling::td//input";
        driver.findElement(By.xpath(InputBox_CreateInvoicePage)).sendKeys(testData);
        Thread.sleep(500);
    }

    public void create_Invoice() throws InterruptedException {

        String createInvoice = "//a[normalize-space()='Create Invoice']";

        driver.findElement(By.xpath("//div[@title='Tasks']//a")).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(createInvoice)));
        logStepWithScreenshot("User clicked on Tasks & will click to create Invoice Url");
        driver.findElement(By.xpath(createInvoice)).click();
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@title,'Create Invoice: ')]")));
        logStepWithScreenshot("Create Invoice page is loaded successfully");

        createInvoice_InputFields_GenericXpath("Business Unit", "McGrath RentCorp");
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//li[text()='McGrath RentCorp']")));
        driver.findElement(By.xpath("//li[text()='McGrath RentCorp']")).click();
        Thread.sleep(200);

        createInvoice_InputFields_GenericXpath("Supplier", "A-1 FIRE PROTECTION");
        Thread.sleep(200);
        createInvoice_InputFields_GenericXpath("Supplier", String.valueOf(Keys.SPACE));
        Thread.sleep(200);
        createInvoice_InputFields_GenericXpath("Supplier", String.valueOf(Keys.BACK_SPACE));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//li[text()='A-1 FIRE PROTECTION 29269 20-2148971  UVFS CORPORATION']")));
        driver.findElement(By.xpath("//li[text()='A-1 FIRE PROTECTION 29269 20-2148971  UVFS CORPORATION']")).click();

        driver.findElement(By.xpath("//label[text()='Legal Entity']//parent::td//following-sibling::td//input")).getAttribute("value").isEmpty();

        By LegalEntity_dropdownOption = By.xpath("//label[text()='Legal Entity']//parent::td//following-sibling::td//input");

        wait.until(driver -> !driver.findElement(LegalEntity_dropdownOption).getAttribute("value").isEmpty());

        createInvoice_InputFields_GenericXpath("Number", Invoice_Num);
        createInvoice_InputFields_GenericXpath("Amount", "1.00");
        driver.findElement(By.xpath("//label[normalize-space()='Description']//parent::td//following-sibling::td//textarea")).sendKeys("McGrath");
        logStepWithScreenshot("User Populated all Invoice details");
        driver.findElement(By.xpath("//a[normalize-space()='Save']")).click();

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@title,'Create Invoice: ')]")));
        Thread.sleep(5000);
        String get_Invoice[] = driver.findElement(By.xpath("//div[contains(@title,'Create Invoice: ')]//h1")).getText().split("Create Invoice: ");
        String get_InvoiceNumber = get_Invoice[1].trim();

        if (get_InvoiceNumber.isEmpty()) {
            Assert.fail("No Invoice Number generated");
        }
        Assert.assertTrue(driver.findElement(By.xpath("//div[contains(@title,'Create Invoice: " + get_InvoiceNumber + "')]")).isDisplayed(), "InvoiceNumber created");

        logStepWithScreenshot("User clicked on Save Button, Invoice number is generated");

        driver.findElement(By.xpath("//a[normalize-space()='Save and Close']")).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Tasks']//a")));
        logStepWithScreenshot("User clicked on Save and Close,return back to Invoice Page");
    }


    @Test
    public void Generate_Invoice() throws InterruptedException {

        launchBrowserAndURL();
        login();
        userLandedOnHomePage();
        selectPayableFromHorizontalScroll();
        clickInvoiceAppInPayableTab();
        create_Invoice();
        logout();
        closeAllWindows();

    }
}
