package utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;

import java.io.File;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;

public class BaseTest {

    protected WebDriver driver;
    protected WebDriverWait wait;
    protected ExtentReports extent;
    protected ExtentTest test;

    @BeforeClass
    public void setUp() {
        // Ensure chromedriver is installed and on PATH (/usr/local/bin/chromedriver)
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless");              // run without GUI
        options.addArguments("--no-sandbox");            // required for Linux
        options.addArguments("--disable-dev-shm-usage"); // overcome limited resource problems

        driver = new ChromeDriver(options);
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    @BeforeTest
    protected void setupReport() {
        extent = ExtentManager.getExtent();
        test = extent.createTest("Search Invoice Test");
    }

    @AfterTest
    protected void tearDown() {
        if (driver != null) {
            driver.quit();
        }
        if (extent != null) {
            extent.flush();
        }
    }

    // common utilities
    protected String captureScreenshot(String stepName) {
        try {
            TakesScreenshot ts = (TakesScreenshot) driver;
            File src = ts.getScreenshotAs(OutputType.FILE);

            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS").format(new Date());
            String runDir = System.getProperty("user.dir") + "/test-output/Run_" + ExtentManager.runId;
            String screenshotDir = runDir + "/screenshots/";
            new File(screenshotDir).mkdirs();

            String fileName = stepName.replaceAll("[^a-zA-Z0-9]", "_") + "_" + timestamp + ".png";
            File dest = new File(screenshotDir + fileName);
            FileUtils.copyFile(src, dest);

            return "screenshots/" + fileName;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    protected void logStepWithScreenshot(String stepName) {
        String path = captureScreenshot(stepName);
        test.pass(stepName, MediaEntityBuilder.createScreenCaptureFromPath(path).build());
    }

    protected void waitForPageLoad(WebElement element) {
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    protected void launchBrowserAndURL() {
        // Reuse the same driver initialized in setUp()
        String url = System.getProperty("app.url");
        System.out.println("URL passed :: "+url);

        driver.get(url);
        waitForPageLoad(driver.findElement(By.xpath("//input[@id='userid']")));
        Assert.assertEquals(driver.getTitle(), "Sign In");
    }

    protected void login() {
        String userId = System.getProperty("app.username");
        String password = System.getProperty("app.password");

        System.out.println("userId :: "+userId);
        System.out.println("password :: "+password);

        driver.findElement(By.xpath("//input[@id='userid']")).sendKeys(userId);
        driver.findElement(By.xpath("//input[@id='password']")).sendKeys(password);

        logStepWithScreenshot("User is getting logged In to the portal");
        driver.findElement(By.xpath("//button[normalize-space()='Sign In']")).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Home']")));
        logStepWithScreenshot("User landed on First Screen");
    }

    protected void logout() {
        driver.findElement(By.xpath("//img[@title='Settings and Actions']")).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Sign Out']")));
        logStepWithScreenshot("User will Signout");
        driver.findElement(By.xpath("//a[normalize-space()='Sign Out']")).click();
    }


    protected void closeAllWindows(){
        driver.quit();
    }

    public void userLandedOnHomePage() {
        driver.findElement(By.xpath("//a[@title='Home']")).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='HCM Experience Design Studio']")));
        logStepWithScreenshot("User clicked on home icon, and landed on Home screen");
        Assert.assertEquals(driver.getTitle(), "Oracle Fusion Cloud Applications");
    }

    public void selectPayableFromHorizontalScroll() throws InterruptedException {
        By rightArrow = By.xpath("//div[@id='clusters-right-nav']");
        By TabName = By.xpath("//a[normalize-space()='Payables']");

        int maxClicks = 4;
        int count = 0;

        while (count < maxClicks) {
            if (driver.findElements(TabName).size() > 0 && driver.findElement(TabName).isDisplayed()) {
                driver.findElement(TabName).click();
                break;
            }
            wait.until(ExpectedConditions.elementToBeClickable(rightArrow)).click();
            Thread.sleep(800);
            count++;
        }
    }

    public void clickInvoiceAppInPayableTab() {
        logStepWithScreenshot("User is inside Payable tab, and user will click Invoices");
        waitForPageLoad(driver.findElement(By.xpath("(//a[normalize-space()='Invoices'])[2]")));
        driver.findElement(By.xpath("(//a[normalize-space()='Invoices'])[2]")).click();
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[normalize-space()='Invoice Number']")));
        logStepWithScreenshot("User landed into Invoice page");
    }
}