package utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ExtentManager {

    public static ExtentReports extent;
    public static String runId;

    public static ExtentReports getExtent() {

        if (extent != null)
            return extent;

        runId = new SimpleDateFormat("yyyyMMdd_HHmmss")
                .format(new Date());

        String basePath =
                System.getProperty("user.dir")
                        + "/test-output/Run_" + runId;

        new File(basePath + "/screenshots").mkdirs();

        String reportPath = basePath + "/ExtentReport.html";

        ExtentSparkReporter spark =
                new ExtentSparkReporter(reportPath);

        spark.config().setReportName("Automation Test Report");
        spark.config().setDocumentTitle("Execution Report");

        extent = new ExtentReports();
        extent.attachReporter(spark);

        return extent;
    }
}
