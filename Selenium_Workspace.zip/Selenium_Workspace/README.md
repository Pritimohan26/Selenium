# Oracle Automation Framework

Selenium TestNG automation framework for Oracle application.

## Tech Stack
- Java
- Selenium WebDriver
- TestNG
- Maven

## How to Run
Run testng.xml or use:
mvn test
